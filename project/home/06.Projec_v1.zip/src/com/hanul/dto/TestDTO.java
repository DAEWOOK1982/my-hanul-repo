package com.hanul.dto;

import java.io.Serializable;

public class TestDTO implements Serializable {
	private String subject; 
	
	private int code, test1, test2, test3, test4, test5, test6, test7, test8, test9, test10;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getTest1() {
		return test1;
	}

	public void setTest1(int test1) {
		this.test1 = test1;
	}

	public int getTest2() {
		return test2;
	}

	public void setTest2(int test2) {
		this.test2 = test2;
	}

	public int getTest3() {
		return test3;
	}

	public void setTest3(int test3) {
		this.test3 = test3;
	}

	public int getTest4() {
		return test4;
	}

	public void setTest4(int test4) {
		this.test4 = test4;
	}

	public int getTest5() {
		return test5;
	}

	public void setTest5(int test5) {
		this.test5 = test5;
	}

	public int getTest6() {
		return test6;
	}

	public void setTest6(int test6) {
		this.test6 = test6;
	}

	public int getTest7() {
		return test7;
	}

	public void setTest7(int test7) {
		this.test7 = test7;
	}

	public int getTest8() {
		return test8;
	}

	public void setTest8(int test8) {
		this.test8 = test8;
	}

	public int getTest9() {
		return test9;
	}

	public void setTest9(int test9) {
		this.test9 = test9;
	}

	public int getTest10() {
		return test10;
	}

	public void setTest10(int test10) {
		this.test10 = test10;
	}

		
	
}
